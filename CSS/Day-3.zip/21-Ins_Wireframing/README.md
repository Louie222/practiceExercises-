## Activity 21: Create a Wireframe (Instructor)

The following image shows the start of a wireframe for the mini-project for this unit:

![Example of an unfinished wireframe with its row and columns highlighted.](./assets/Images/01-unfinished-wireframe.png)

* The areas outlined in red represent rows.

* The areas outlined in blue represent columns.

---
© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.